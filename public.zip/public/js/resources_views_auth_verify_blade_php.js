(self["webpackChunk"] = self["webpackChunk"] || []).push([["resources_views_auth_verify_blade_php"],{

/***/ "./resources/views/auth/verify.blade.php":
/*!***********************************************!*\
  !*** ./resources/views/auth/verify.blade.php ***!
  \***********************************************/
/***/ (() => {

throw new Error("Module parse failed: Unexpected character '@' (1:0)\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\n> @extends('layouts.app')\n| \n| @section('content')");

/***/ })

}]);