@extends('layouts.app')

@section('content')
<epsilon></epsilon>
@endsection
<script>
    // import Epsilon from "../../js/components/Epsilon";
    // export default {
    //     components: {Epsilon}
    // }
</script>
